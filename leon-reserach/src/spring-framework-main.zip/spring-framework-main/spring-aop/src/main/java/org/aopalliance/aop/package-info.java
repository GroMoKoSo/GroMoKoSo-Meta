/**
 * The core AOP Alliance advice marker.
 */
@NullMarked
package org.aopalliance.aop;

import org.jspecify.annotations.NullMarked;
