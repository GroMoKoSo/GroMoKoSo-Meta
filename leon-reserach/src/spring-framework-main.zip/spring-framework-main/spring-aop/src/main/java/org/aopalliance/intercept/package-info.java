/**
 * The AOP Alliance reflective interception abstraction.
 */
@NullMarked
package org.aopalliance.intercept;

import org.jspecify.annotations.NullMarked;
