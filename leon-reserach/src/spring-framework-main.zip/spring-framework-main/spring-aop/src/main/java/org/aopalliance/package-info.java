/**
 * Spring's variant of the AOP Alliance interfaces.
 */
@NullMarked
package org.aopalliance;

import org.jspecify.annotations.NullMarked;
