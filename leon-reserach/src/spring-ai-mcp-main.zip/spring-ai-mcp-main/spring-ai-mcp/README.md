# Spring AI MCP Spring

Spring Integration module for Model Control Protocol (MCP) that provides Spring-specific functionality for working with MCP clients.

Find more at [Java MCP SDK](https://docs.spring.io/spring-ai-mcp/reference/spring-mcp.html)