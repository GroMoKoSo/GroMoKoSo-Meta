# Java MCP SDK

Java SDK implementation of the Model Context Protocol, enabling seamless integration with language models and AI tools.

Find more at [Java MCP SDK](https://docs.spring.io/spring-ai-mcp/reference/mcp.html)